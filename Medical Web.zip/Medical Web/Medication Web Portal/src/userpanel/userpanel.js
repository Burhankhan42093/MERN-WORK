import React, { Component } from "react";

class UserPanel extends Component {
  state = {};
  render() {
    return <h1>Welcome to user panel</h1>;
  }
}

export default UserPanel;

import React from "react";

// reactstrap components
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
} from "reactstrap";
import { reactLocalStorage } from "reactjs-localstorage";
// core components
import PanelHeader from "components/PanelHeader/PanelHeader.js";
import axios from "axios";

class AddDeliveryBoy extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      ProductName: "",
      Potency: "",
      Description: "",
      BarCode: "",

      error: false,
      register: false,
    };

    this.handleProductName = this.handleProductName.bind(this);
    this.handleProductPotency = this.handleProductPotency.bind(this);
    this.handleProductDescription = this.handleProductDescription.bind(this);
    this.handleProductBarCode = this.handleProductBarCode.bind(this);

    this.addProduct = this.addProduct.bind(this);
  }

  handleProductName(event) {
    this.setState({
      ProductName: event.target.value,
    });
  }
  handleProductPotency(event) {
    this.setState({
      Potency: event.target.value,
    });
  }
  handleProductDescription(event) {
    this.setState({
      Description: event.target.value,
    });
  }
  handleProductBarCode(event) {
    this.setState({
      BarCode: event.target.value,
    });
  }

  addProduct() {
    console.log("submitted");

    if (
      this.state.ProductName.length <= 0 &&
      this.state.Potency.length <= 0 &&
      this.state.Description.length <= 0 &&
      this.state.BarCode.length <= 0
    ) {
      this.errorText = "Please fill all fields *";
      this.successText = "";
      this.setState({
        error: true,
      });
    } else if (this.state.ProductName.length <= 0) {
      this.errorText = "Delivery Boy Name is required *";
      this.successText = "";
      this.setState({
        error: true,
      });
    } else if (this.state.Potency.length <= 0) {
      this.errorText = "City is required *";
      this.successText = "";
      this.setState({
        error: true,
      });
    } else if (this.state.Description.length <= 0) {
      this.errorText = "Address is required *";
      this.successText = "";
      this.setState({
        error: true,
      });
    } else if (this.state.BarCode.length <= 0) {
      this.errorText = "Phone Number is required *";
      this.successText = "";
      this.setState({
        error: true,
      });
    } else if (!Number(this.state.BarCode)) {
      this.errorText = "Phone Number must be a Number *";
      this.successText = "";
      this.setState({
        error: true,
      });
    } else {
      axios
        .post(
          "http://localhost:3000/medication/api/adddeliveryboy",
          {
            productName: this.state.ProductName,
            potency: this.state.Potency,
            description: this.state.Description,
            barCode: this.state.BarCode,
          },
          {
            headers: {
              "Access-Control-Allow-Origin": "http://localhost:3000",
              "Content-Type": "application/json",
            },
          }
        )
        .then((res) => {
          console.log("ServerResponse", res.data.message);
          if (res.data.message === "success") {
            this.errorText = "";
            this.successText = "Delivery Boy added successfully *";
            this.setState({
              register: true,
              ProductName: "",
              Potency: "",
              Description: "",
              BarCode: "",
            });
          } else if (res.data.message === "error") {
            this.successText = "";
            this.errorText = "Something went wrong *";
            this.setState({
              error: true,
            });
          }
        })
        .catch((err) => {
          console.log("error", err);
        });
    }
  }

  render() {
    return (
      <>
        <PanelHeader size="sm" />
        <div className="content">
          <Row>
            <Col md="8">
              <Card>
                <CardHeader>
                  <h5 className="title">Add Product</h5>
                </CardHeader>
                <CardBody>
                  <Form>
                    <Row>
                      <Col className="pr-1" md="5">
                        <FormGroup>
                          <label>Company (disabled)</label>
                          <Input
                            defaultValue="Creative Code Inc."
                            disabled
                            placeholder="Company"
                            type="text"
                          />
                        </FormGroup>
                      </Col>
                      <Col className="px-1" md="3">
                        <FormGroup></FormGroup>
                      </Col>
                      <Col className="pl-1" md="4">
                        <FormGroup></FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col className="pr-1" md="6">
                        <FormGroup>
                          <label>Delivery Boy Name *</label>
                          <Input
                            placeholder="Name"
                            type="text"
                            value={this.state.ProductName}
                            onChange={this.handleProductName}
                            maxLength={25}
                          />
                        </FormGroup>
                      </Col>
                      <Col className="pl-1" md="6">
                        <FormGroup>
                          <label>Set password*</label>
                          <Input
                            placeholder="Password"
                            type="text"
                            value={this.state.Potency}
                            onChange={this.handleProductPotency}
                            maxLength={10}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label>Address *</label>
                          <Input
                            placeholder="Address"
                            type="text"
                            value={this.state.Description}
                            onChange={this.handleProductDescription}
                            maxLength={80}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col className="pr-1" md="4">
                        <FormGroup>
                          <label>Mobile Number *</label>
                          <Input
                            placeholder="1231235435"
                            type="text"
                            value={this.state.BarCode}
                            onChange={this.handleProductBarCode}
                            maxLength={20}
                          />
                        </FormGroup>
                      </Col>
                      <Col className="px-1" md="4">
                        <FormGroup>
                          {/* <label>Country</label>
                          <Input
                            defaultValue="Andrew"
                            placeholder="Country"
                            type="text"
                          /> */}
                        </FormGroup>
                      </Col>
                      <Col className="pl-1" md="4">
                        <FormGroup>
                          <label></label>
                          <Button
                            style={{
                              marginLeft: 50,
                              marginTop: 100,
                            }}
                            onClick={this.addProduct}
                          >
                            Add Delivery Boy
                          </Button>
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label>
                            {" "}
                            {this.state.error ? (
                              <label class="error" style={{ color: "red" }}>
                                {this.errorText}
                              </label>
                            ) : (
                              <h4></h4>
                            )}
                            {this.state.register ? (
                              <label class="error" style={{ color: "green" }}>
                                {this.successText}
                              </label>
                            ) : (
                              <h4></h4>
                            )}
                          </label>
                        </FormGroup>
                      </Col>
                    </Row>
                  </Form>
                </CardBody>
              </Card>
            </Col>
            <Col md="4">
              <Card className="card-user">
                <div className="image">
                  <img alt="..." src={require("assets/img/bg5.jpg")} />
                </div>
                <CardBody>
                  <div className="author">
                    <a href="#pablo" onClick={(e) => e.preventDefault()}>
                      <img
                        alt="..."
                        className="avatar border-gray"
                        src={require("assets/img/logo.jpg")}
                      />
                      <h5 className="title">
                        {/* {reactLocalStorage.get("storename")} */}
                      </h5>
                    </a>
                    <p className="description">
                      {/* {reactLocalStorage.get("email")} */}
                    </p>
                  </div>
                  <p className="description text-center">
                    "Add Delivery <br />
                    boys to your store and <br />
                    manage orders"
                  </p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </>
    );
  }
}

export default AddDeliveryBoy;

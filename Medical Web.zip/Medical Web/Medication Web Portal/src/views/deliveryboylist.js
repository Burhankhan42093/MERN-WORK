import React from "react";

// reactstrap components
import {
  Card,
  CardBody,
  CardHeader,
  CardTitle,
  Table,
  Row,
  Col,
} from "reactstrap";
import axios from "axios";
// core components
import PanelHeader from "components/PanelHeader/PanelHeader.js";

import { thead, tbody } from "variables/general";

class DeliveryBoyList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      order: false,
      ordersData: "",
    };
  }

  componentDidMount() {
    this.getOrdersFromDatabase();
  }

  getOrdersFromDatabase() {
    axios
      .get("http://localhost:3000/medication/api/getAllDeliveryBoys")
      .then((res) => {
        console.log("statusTextof res", res);
        if (res.data.message.length > 0) {
          this.productStatus = "";
          this.setState({
            order: true,
            ordersData: res,
          });
        } else {
          this.productStatus = "No Delivery Boy Exist";
          console.log("No product exist");
          this.setState({
            order: false,
          });
        }
      })
      .catch((err) => {
        this.productStatus =
          " An error occured while fetching Delivery Boys List";
        this.setState({
          order: false,
        });
      });
  }

  statusButton(index) {
    return (
      <button
        type="button"
        class="btn btn-danger"
        onClick={() => this.changestatus(index)}
      >
        Delete
      </button>
    );
  }

  changestatus = (index) => {
    axios
      .post(
        "http://localhost:3000/medication/api/deleteDeliveryBoy",
        {
          id: this.state.ordersData.data.message[index]._id,
        },
        {
          headers: {
            "Access-Control-Allow-Origin": "http://localhost:3000",
            "Content-Type": "application/json",
          },
        }
      )
      .then((res) => {
        this.setState({
          ordersData: res,
        });
      })
      .catch((err) => {});
  };

  renderTableData() {
    return (
      <Table striped bordered hover>
        <thead class="thead-dark">
          <tr>
            <th style={{ textAlign: "center" }}>#</th>
            <th style={{ textAlign: "center" }}>Name</th>
            <th style={{ textAlign: "center" }}>Phone Number</th>
            <th style={{ textAlign: "center" }}>Address</th>
            <th style={{ textAlign: "center" }}>Remove</th>
          </tr>
        </thead>
        <tbody>
          {this.state.ordersData.data.message.map((order, index) => {
            const { username, city, address, phonenumber } = order;
            return (
              <tr>
                <td style={{ textAlign: "center" }}>{index + 1}</td>
                <td style={{ textAlign: "center" }}> {username}</td>
                <td style={{ textAlign: "center" }}>{phonenumber}</td>
                <td style={{ textAlign: "center" }}>{address}</td>
                <td style={{ textAlign: "center" }}>
                  {this.statusButton(index)}
                </td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    );
  }

  render() {
    return (
      <>
        <PanelHeader size="sm" />
        <div className="content">
          <Row>
            <Col xs={12}>
              <Card>
                <CardHeader>
                  <CardTitle tag="h4">View Delivery Boys List</CardTitle>
                </CardHeader>
                <CardBody>
                  {this.state.order ? (
                    this.renderTableData()
                  ) : (
                    <span style={{ color: "red" }}>{this.productStatus}</span>
                  )}
                </CardBody>
              </Card>
            </Col>
          </Row>
        </div>
      </>
    );
  }
}

export default DeliveryBoyList;

import React from "react";
// javascript plugin used to create scrollbars on windows
import PerfectScrollbar from "perfect-scrollbar";
// reactstrap components
import { Route, Switch, Redirect } from "react-router-dom";
// core components
import DemoNavbar from "components/Navbars/DemoNavbar.js";
import Footer from "components/Footer/Footer.js";
import Sidebar from "components/Sidebar/Sidebar.js";
import FixedPlugin from "components/FixedPlugin/FixedPlugin.js";
// import routes from "../routes.js";
import adminroutes from "../adminroutes.js";
import { reactLocalStorage } from "reactjs-localstorage";
import TableList from "views/TableList.js";
import UserPage from "views/UserPage.js";
import AddDeliveryBoy from "views/adddeliveryboy.js";
import DeliveryBoyList from "views/deliveryboylist.js";

var ps;

class Dashboard extends React.Component {
  state = {
    backgroundColor: "blue",
    render: false,
  };
  mainPanel = React.createRef();
  componentDidMount() {
    console.log("StorageAdminPanel", reactLocalStorage.get("currentuser"));
    if (reactLocalStorage.get("currentuser") === "deliveryboy") {
      this.routes = [
        {
          path: "/delivery-store",
          name: "View Orders",
          icon: "files_paper",
          component: TableList,
          layout: "/admin",
        },
      ];
      this.path = "/admin/delivery-store";
      this.setState({
        render: true,
      });
    } else if (reactLocalStorage.get("currentuser") === "user") {
      this.routes = [
        {
          path: "/user-store",
          name: "Add Product",
          icon: "users_single-02",
          component: UserPage,
          layout: "/admin",
        },
      ];
      this.path = "/admin/user-store";
      this.setState({ render: true });
    } else if (reactLocalStorage.get("currentuser") === "admin") {
      this.routes = [
        {
          path: "/admin-store",
          name: "Add Delivery Boy",
          icon: "users_single-02",
          component: AddDeliveryBoy,
          layout: "/admin",
        },
        {
          path: "/admin--store",
          name: "View Delivery Boys",
          icon: "files_paper",
          component: DeliveryBoyList,
          layout: "/admin",
        },
      ];
      this.path = "/admin/admin-store";
      this.setState({
        render: true,
      });
    }

    if (navigator.platform.indexOf("Win") > -1) {
      ps = new PerfectScrollbar(this.mainPanel.current);
      document.body.classList.toggle("perfect-scrollbar-on");
    }
  }
  componentWillUnmount() {
    if (navigator.platform.indexOf("Win") > -1) {
      ps.destroy();
      document.body.classList.toggle("perfect-scrollbar-on");
    }
  }
  componentDidUpdate(e) {
    if (e.history.action === "PUSH") {
      document.documentElement.scrollTop = 0;
      document.scrollingElement.scrollTop = 0;
      this.mainPanel.current.scrollTop = 0;
    }
  }
  handleColorClick = (color) => {
    this.setState({ backgroundColor: color });
  };
  render() {
    return (
      <div>
        {this.state.render ? (
          <div className="wrapper">
            <Sidebar
              {...this.props}
              routes={this.routes}
              backgroundColor={this.state.backgroundColor}
            />
            <div className="main-panel" ref={this.mainPanel}>
              <DemoNavbar {...this.props} />
              <Switch>
                {this.routes.map((prop, key) => {
                  return (
                    <Route
                      path={prop.layout + prop.path}
                      component={prop.component}
                      key={key}
                    />
                  );
                })}
                <Redirect from="/admin" to={this.path} />
              </Switch>
              <Footer fluid />
            </div>
          </div>
        ) : (
          <h1>wait</h1>
        )}
      </div>
    );
  }
}

export default Dashboard;

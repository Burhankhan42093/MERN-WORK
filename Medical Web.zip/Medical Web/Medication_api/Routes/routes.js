const express = require("express");
const router = express.Router();
const ProductController = require("../Controllers/ProductController");
const FranchiseController = require("../Controllers/FranchiseController");
const AdminController = require("../Controllers/AdminController");
const OrderController = require("../Controllers/OrderController");
const DeliveryBoyController = require("../Controllers/DeliveryBoyController");
const { DeleteDeliveryBoy } = require("../Controllers/DeliveryBoyController");

router.post("/adduser", FranchiseController.addNewUser);

router.post("/finduser", FranchiseController.findFranchiseUser);

router.get("/findallstores", FranchiseController.findAllFranchises);

router.post("/AddProduct", ProductController.Addproduct);

router.post("/findallproducts", ProductController.getAllProducts);

router.post("/addadmin", AdminController.addAdmin);

router.post("/findadmin", AdminController.findUser);

router.post("/placeorder", OrderController.placeorder);

router.get("/findallorders", OrderController.findallorders);

router.post("/changeorderstatus", OrderController.changeOrderStatus);

router.post("/adddeliveryboy", DeliveryBoyController.AddDeliveryBoy);

router.get("/getAllDeliveryBoys", DeliveryBoyController.getAllDeliveryBoys);

router.post("/deleteDeliveryBoy", DeliveryBoyController.DeleteDeliveryBoy);

router.post("/findDeliveryBoy", DeliveryBoyController.findDeliveryBoy);

module.exports = router;

const routes = require("./Routes/routes");
const mongoose = require("mongoose");
const express = require("express");
const app = express();
var cors = require("cors");
app.use(cors());

//Establish a connection with Mongo DB
const dbURI ="mmongodb+srv://arbaaz:arbaaz123@cluster0.psbqq.mongodb.net/dbarbaaz?retryWrites=true&w=majority"

mongoose.connect(dbURI,
  { useNewUrlParser:true,useUnifiedTopology:true,useCreateIndex:true },
  (error) => {
    if (!error) {
      console.log("Mongo DB connection established");
    } else {
      console.log("Mongo DB connection failure");
    }
  }
);

//Make a router using express to call different api's

app.use(express.json());
app.use("/medication/api", routes);

///Setting up port for express server to call api's on local host

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Express Server is running on port ${port}`);
});

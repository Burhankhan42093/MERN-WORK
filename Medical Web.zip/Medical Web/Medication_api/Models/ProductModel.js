const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const productSchema = new Schema(
  {
    productName: {
      type: String,
    },
    potency: {
      type: String,
    },
    description: {
      type: String,
    },
    barCode: {
      type: String,
    },
    storeName: {
      type: String,
    },
    storeEmail: {
      type: String,
    },
  },
  { timestamps: true }
);

const Product = mongoose.model("products", productSchema);

module.exports = Product;

const mongoose = require("mongoose");
const Schema = mongoose.Schema;

//Set a Schema for Franchise Users

const franchiseUserSchema = new Schema(
  {
    storeName: {
      type: String,
    },
    proprieterName: {
      type: String,
    },
    Description: {
      type: String,
    },
    City: {
      type: String,
    },
    Address: {
      type: String,
    },
    phoneNumber: {
      type: String,
    },
    email: {
      type: String,
    },
    password: {
      type: String,
    },
  },
  { timestamps: true } //time stamps true: automatically handles creation and updation time
);

/// "franchises" is the name of Collection (Table in mongo db)

const franchiseUser = mongoose.model("franchises", franchiseUserSchema);
module.exports = franchiseUser;

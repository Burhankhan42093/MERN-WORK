const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const OrderSchema = new Schema(
  {
    username: {
      type: String,
    },
    phonenumber: {
      type: String,
    },
    address: {
      type: String,
    },
    orderstatus: {
      type: String,
    },
    orderitems: {
      type: [{}],
    },
  },
  { timestamps: true }
);

const Order = mongoose.model("orders", OrderSchema);
module.exports = Order;

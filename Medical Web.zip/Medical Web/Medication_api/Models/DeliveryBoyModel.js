const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const DeliveryBoySchema = new Schema(
  {
    username: {
      type: String,
    },
    city: {
      type: String,
    },
    address: {
      type: String,
    },
    phonenumber: {
      type: String,
    },
  },
  { timestamps: true }
);

const Delivery = mongoose.model("DeliveryBoys", DeliveryBoySchema);
module.exports = Delivery;

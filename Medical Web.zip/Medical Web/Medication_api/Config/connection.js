const mongoose = require("mongoose");

mongoose.connect(
  "mongodb://haseeb:haseeb123@cluster0-shard-00-00.m0eq8.mongodb.net:27017,cluster0-shard-00-01.m0eq8.mongodb.net:27017,cluster0-shard-00-02.m0eq8.mongodb.net:27017medicalwebportal?ssl=true&replicaSet=atlas-8e9zch-shard-0&authSource=admin&retryWrites=true&w=majority",
  { useNewUrlParser: true, useUnifiedTopology: true },
  (error) => {
    if (!error) {
      console.log("Connection Success with Mongo DB");
    } else {
      console.log("Connection failure with Mongo DB");
    }
  }
);

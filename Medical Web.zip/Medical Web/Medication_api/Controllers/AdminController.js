const monggose = require("mongoose");
const {Admin} = require("../Models/AdminModel");

/// Rest service to Add new Admin user.....you can add new admin user using POSTMAN

const addAdmin = (req, res, next) => {
  let user =  new Admin({
    email: req.body.email,
    password: req.body.password,
  });
  console.log("admin User :",user);

  user
    .save()
    .then((response) => {
      console.log("response", response);
      res.json({
        message: "true",
      });
    })
    .catch((err) => {
      res.json({
        message: "false",
      });
    });
};

////  Rest Service to find admin

const findUser = (req, res, next) => {
  console.log(req.body)
  Admin.find({
    email: req.body.email,
    password: req.body.password,
  })
    .then((response) => {
      console.log("response", response);
      if (response.length > 0) {
        res.json({
          message: "true",
        });
      } else {
        res.json({
          message: "false",
        });
      }
    })
    .catch((err) => {
      res.json({
        message: "server error",
      });
    });
};

module.exports = {
  addAdmin,
  findUser,
};

const mongoose = require("mongoose");
const franchiseUser = require("../Models/FranchiseModel");
const { response } = require("express");

///  Find user for login

const findFranchiseUser = (req, res, next) => {
  franchiseUser
    .find({
      email: req.body.email,
      password: req.body.password,
    })
    .then((response) => {
      console.log("response", response);
      console.log("response", response[0].email);
      if (response.length > 0) {
        res.json({
          message: "true",
          email: response[0].email,
          store_name: response[0].storeName,
        });
      } else {
        res.json({
          message: "false",
        });
      }
    })
    .catch((err) => {
      res.json({
        message: "false",
      });
    });
};

// Store document (Record) for a new Franchise user

const addNewUser = (req, res, next) => {
  let user = new franchiseUser({
    storeName: req.body.storeName,
    proprieterName: req.body.proprieterName,
    Description: req.body.Description,
    City: req.body.City,
    Address: req.body.Address,
    phoneNumber: req.body.phoneNumber,
    email: req.body.email,
    password: req90.body.password,
  });
  ///check whether user already exists or not
  franchiseUser
    .find({
      email: req.body.email,
    })
    .then((response) => {
      console.log(response)
      console.log("response", response);
      if (response.length > 0) {
        res.json({
          message: "already exists",
        });
      } else {
        ///saving new user
        user
          .save()
          .then((response) => {
            res.json({
              message: "success",
            });
          })
          .catch((err) => {
            res.json({
              message: "error",
            });
          });
      }
    })
    .catch((err) => {
      res.json({
        message: "false",
      });
    });
};

//Find All Franchises/Stores

const findAllFranchises = (req, res, next) => {
  franchiseUser
    .find()
    .sort({ _id: -1 })
    .then((response) => {
      if (response.length > 0) {
        res.json({
          status: "success",
          message: response,
        });
      } else {
        res.json({
          status: "No Stores Exist",
          message: [],
        });
      }
    })
    .catch((error) => {
      res.json({
        status: "error",
        message: [],
      });
    });
};

// Exporting to access these constant inside another modules

module.exports = {
  addNewUser,
  findFranchiseUser,
  findAllFranchises,
};

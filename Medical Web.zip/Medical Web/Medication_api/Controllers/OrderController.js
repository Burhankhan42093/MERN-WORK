const mongoose = require("mongoose");
const Order = require("../Models/OrderModel");

///for saving an order in database

const placeorder = (req, res, next) => {
  var products = [];
  //Parse product names
  var productnames = req.body.productsNamesList;
  var productNamesList = productnames.split(",");
  console.log("productNamesList", productNamesList);
  //Parse product potency
  var productpotency = req.body.productsPotencyList;
  var productsPotencyList = productpotency.split(",");
  //Parse product quantity
  var productQuantity = req.body.productQuantityList;
  var productQuantityList = productQuantity.split(",");
  //Parse store names
  var storeNames = req.body.storeNamesList;
  var storeNamesList = storeNames.split(",");

  var j;
  for (var j = 0; j < productNamesList.length; j++) {
    var orderedProductObject = {
      productName: "",
      productPotency: "",
      productQuantity: "",
      storeName: "",
    };
    orderedProductObject.productName = productNamesList[j];
    orderedProductObject.productPotency = productsPotencyList[j];
    orderedProductObject.productQuantity = productQuantityList[j];
    orderedProductObject.storeName = storeNamesList[j];
    products.push(orderedProductObject);
  }

  let order = new Order({
    username: req.body.customerName,
    phonenumber: req.body.customerPhone,
    address: req.body.customerAddress,
    orderstatus: "pending",
    orderitems: products,
  });

  order
    .save()
    .then((response) => {
      console.log(response);
      res.json({
        status: "success",
      });
    })
    .catch((err) => {
      console.log(err);
      res.json({
        status: "error",
      });
    });
};

//return All order for admin panel

const findallorders = (req, res, next) => {
  Order.find()
    .sort({ _id: -1 })
    .then((response) => {
      res.json({
        message: response,
      });
    })
    .catch((err) => {
      res.json({
        message: "error",
      });
    });
};

//change order status

const changeOrderStatus = (req, res, next) => {
  var query = { _id: req.body.id, username: req.body.username };
  var newValue = { orderstatus: req.body.orderstatus };

  Order.findOneAndUpdate(query, newValue, {
    useFindAndModify: false,
    new: true,
  })
    .then((res) => {
      console.log("updateresponse ", res);
      res.json({
        message: "true",
      });
    })
    .catch((err) => {
      Order.find()
        .sort({ _id: -1 })
        .then((response) => {
          res.json({
            message: response,
          });
        })
        .catch((err) => {
          res.json({
            message: "error",
          });
        });
    });
};

module.exports = {
  placeorder,
  findallorders,
  changeOrderStatus,
};

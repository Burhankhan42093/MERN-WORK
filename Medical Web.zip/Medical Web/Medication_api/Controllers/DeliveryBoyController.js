const mongoose = require("mongoose");
const DeliveryBoy = require("../Models/DeliveryBoyModel");

////code for adding delivery boy

const AddDeliveryBoy = (req, res, next) => {
  let deliveryBoy = new DeliveryBoy({
    username: req.body.productName,
    city: req.body.potency,
    address: req.body.description,
    phonenumber: req.body.barCode,
  });

  //saving new deliveryBoy
  deliveryBoy
    .save()
    .then((response) => {
      res.json({
        message: "success",
      });
    })
    .catch((err) => {
      res.json({
        message: "error",
      });
    });
};

///get All delivery boys

const getAllDeliveryBoys = (req, res, next) => {
  DeliveryBoy.find()
    .sort({ _id: -1 })
    .then((response) => {
      res.json({
        message: response,
      });
    })
    .catch((err) => {
      res.json({
        message: "error",
      });
    });
};

///Delete a delivery boy

const DeleteDeliveryBoy = (req, res, next) => {
  var query = { _id: req.body.id };

  DeliveryBoy.deleteOne(query)
    .then((response) => {
      DeliveryBoy.find()
        .sort({ _id: -1 })
        .then((response) => {
          res.json({
            message: response,
          });
        })
        .catch((err) => {
          res.json({
            message: "error",
          });
        });
    })
    .catch((err) => {
      console.log("updateresponse ", res);
      res.json({
        message: "error",
      });
    });
};

////  Rest Service to find delivery boy

const findDeliveryBoy = (req, res, next) => {
  DeliveryBoy.find({
    username: req.body.email,
    city: req.body.password,
  })
    .then((response) => {
      console.log("response", response);
      if (response.length > 0) {
        res.json({
          message: "true",
        });
      } else {
        res.json({
          message: "false",
        });
      }
    })
    .catch((err) => {
      res.json({
        message: "server error",
      });
    });
};

module.exports = {
  AddDeliveryBoy,
  getAllDeliveryBoys,
  DeleteDeliveryBoy,
  findDeliveryBoy,
};

const mongoose = require("mongoose");
const Product = require("../Models/ProductModel");

////code for adding product

const Addproduct = (req, res, next) => {
  let product = new Product({
    productName: req.body.productName,
    potency: req.body.potency,
    description: req.body.description,
    barCode: req.body.barCode,
    storeName: req.body.storeName,
    storeEmail: req.body.storeEmail,
  });

  //saving new product
  product
    .save()
    .then((response) => {
      res.json({
        message: "success",
      });
    })
    .catch((err) => {
      res.json({
        message: "error",
      });
    });
};

////Get All Products

const getAllProducts = (req, res, next) => {
  console.log(req.body.storeName);
  console.log(req.body.storeEmail);
  Product.find({
    storeName: req.body.storeName,
    storeEmail: req.body.storeEmail,
  })
    .sort({ _id: -1 })
    .then((response) => {
      if (response.length > 0) {
        res.json({
          productsstatus: "success",
          message: response,
        });
      } else {
        res.json({
          productsstatus: "No Product Exist",
          message: [],
        });
      }
    })
    .catch((error) => {
      res.json({
        status: "error",
        message: [],
      });
    });
};

///check whether a products exist or not

module.exports = {
  Addproduct,
  getAllProducts,
};
